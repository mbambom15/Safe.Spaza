from flask import Flask, render_template, Response, redirect, url_for, jsonify, request, session
from flask_login import LoginManager, UserMixin, login_user, login_required, current_user
import cv2 
import numpy as np
from pyzbar.pyzbar import decode
import re
import mysql.connector
from mysql.connector import Error

app = Flask(__name__, template_folder='temp')

app.secret_key = 'your_secret_key'

# Database Connection
conn = mysql.connector.connect(
    host='localhost',
    user='root',
    password='1234567890',
    database='your_database'
)
cursor = conn.cursor()

# Create users table if not exists
# This is how to create table from the py to avoid errors  
#  i only used one tabale for spaza_owner1 and manufacturer i think works best
cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        full_name VARCHAR(255) NOT NULL,
        email VARCHAR(255) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        role VARCHAR(255) NOT NULL,
        location VARCHAR(255)
    )
''')

# Create Product table if not exists    
cursor.execute('''
    CREATE TABLE IF NOT EXISTS Product (
        id INT AUTO_INCREMENT PRIMARY KEY,
        prod_name VARCHAR(255) NOT NULL,
        prod_barcode VARCHAR(255) UNIQUE NOT NULL,
        prod_price DECIMAL(10, 2) NOT NULL,
        prod_quantity INT NOT NULL,
        prod_description TEXT
    )
''')

# Create sales table if not exists
cursor.execute('''
    CREATE TABLE IF NOT EXISTS sales (
        id INT AUTO_INCREMENT PRIMARY KEY,
        product_id INT NOT NULL,
        quantity INT NOT NULL,
        sale_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (product_id) REFERENCES Product(id)
    )
''')

# Create spaza_owner table if not exists
cursor.execute('''
    CREATE TABLE IF NOT EXISTS spaza_owner1 (
        id INT AUTO_INCREMENT PRIMARY KEY,
        full_name VARCHAR(255) NOT NULL,    
        email VARCHAR(255) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        location VARCHAR(255),
        role ENUM('manufacturer', 'spaza_owner') NOT NULL,
        cell_number VARCHAR(10)
    )
''')



# Create manufacturer table if not exists
cursor.execute('''
    CREATE TABLE IF NOT EXISTS manufacturer (
        id INT AUTO_INCREMENT PRIMARY KEY,
        full_name VARCHAR(255) NOT NULL,
        email VARCHAR(255) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        location VARCHAR(255)
    )
''')
conn.commit()
# Global variables for barcode scanning
scanned_data = None
camera_active = False
cap = None

def check_password_strength(password):
    if len(password) >= 8 and re.search(r"[A-Z]", password) and re.search(r"[a-z]", password) and re.search(r"\d", password) and re.search(r"[@$!%*?&]", password):
        return "Strong"
    elif len(password) >= 6 and re.search(r"[A-Za-z]", password) and re.search(r"\d", password):
        return "Medium"
    else:
        return "Weak"

def validate_phone_number(phone_number):
    return phone_number.startswith('0') and len(phone_number) == 9 and phone_number.isdigit()

def generate_frames():
    global scanned_data, camera_active, cap

    if cap is None:
        cap = cv2.VideoCapture(0)
        cap.set(3, 640)  # Set width
        cap.set(4, 480)  # Set height

    while True:
        if camera_active:
            success, img = cap.read()
            if not success:
                break
            else:
                # Decode barcodes in the current frame
                for barcode in decode(img):
                    scanned_data = barcode.data.decode('utf-8')  # Store scanned data
                    camera_active = False  # Stop camera after scanning

                    # Draw bounding box around barcode
                    pts = np.array([barcode.polygon], np.int32)
                    pts = pts.reshape((-1, 1, 2))
                    cv2.polylines(img, [pts], True, (255, 0, 255), 5)

                    # Display barcode text on frame
                    x, y, _, _ = barcode.rect
                    cv2.putText(img, scanned_data, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 0, 255), 2)

                _, buffer = cv2.imencode('.jpg', img)
                frame = buffer.tobytes()
                yield (b'--frame\r\n'
                       b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
        else:
            # When camera is inactive, display a paused frame
            blank_frame = np.zeros((480, 640, 3), dtype=np.uint8)
            cv2.putText(blank_frame, "Camera Paused", (220, 240), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
            _, buffer = cv2.imencode('.jpg', blank_frame)
            frame = buffer.tobytes()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

@app.route('/')
def home():
    
    return redirect(url_for('spazalogin'))

@app.route('/spazalogin')
def spazalogin():
    return render_template('spazalogin.html')

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

@app.route('/scanForManufacturer')
@login_required
def scanForManufacturer():
    return render_template('scanForManufacturer.html')

@app.route('/scan')
def scan():
    return render_template('scan.html')

@app.route('/tel_verification', methods=['GET', 'POST'])



@app.route('/login_manufacturer', methods=['GET', 'POST'])
def login_manufacturer():
    user = User("1", "demo@example.com")
    login_user(user)
    # Authenticate manufacturer login
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        cursor.execute("SELECT id, full_name, password FROM spaza_owner1 WHERE email = %s AND role = 'manufacturer'", (email,))
        user = cursor.fetchone()

        if user and user[2] == password:
            session['user_id'] = user[0]
            session['full_name'] = user[1]
            return redirect('/manudashboard')
        else:
            return render_template('login_manufacturer.html', message="Invalid email or password!")
    
    return render_template('login_manufacturer.html')

@app.route('/login_spazaOwner', methods=['GET', 'POST'])
def login_spazaOwner():
    user = User("1", "demo@example.com")
    login_user(user)
    # Authenticate spaza owner login
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        cursor.execute("SELECT id, full_name, password FROM spaza_owner1 WHERE email = %s AND role = 'spaza_owner'", (email,))
        user = cursor.fetchone()

        if user and user[2] == password:
            session['user_id'] = user[0]
            session['full_name'] = user[1]
            return redirect('/shopowner')
        
        else:
            return render_template('login_spazaOwner.html', message="Invalid email or password!")
    
    return render_template('login_spazaOwner.html')

@app.route('/update_password', methods=['GET', 'POST'])
def update_password():
    if request.method == 'POST':
        email = request.form['email']
        new_password = request.form['new_password']

        # Check password strength
        password_strength = check_password_strength(new_password)
        if password_strength == "Weak":
            return render_template('update_password.html', message="Password is too weak!")

        try:
            cursor.execute("SELECT email FROM spaza_owner1 WHERE email = %s", (email,))
            user = cursor.fetchone()
            if not user:
                return render_template('update_password.html', message="Email not found in the database!")
            else:
                cursor.execute("UPDATE spaza_owner1 SET password = %s WHERE email = %s", (new_password, email))
            conn.commit()
            return render_template('update_password.html', message="Password updated successfully!")
        except Error as e:
            return render_template('update_password.html', message=f"Error: {str(e)}")
        
    return render_template('update_password.html')

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('full_name', None)
    return redirect('/')

@app.route('/signup_manufacturer', methods=['GET', 'POST'])
def signup_manufacturer():
    if request.method == 'POST':
        full_name = request.form.get('full_name')
        email = request.form.get('email')
        password = request.form.get('password')
        location = request.form.get('location', '')  # Optional field
        role = 'manufacturer'
        cell_number = request.form.get('cellNo', '')  # Optional field

        # Check phone number validity

       #something is wrong

        # Check password strength
        password_strength = check_password_strength(password)
        if password_strength == "Weak":
            redirect('signup_manufacturer.html', message="Password is too weak!")


        try:
             cursor.execute('''
                INSERT INTO spaza_owner1 (full_name, email, password, role, location, cell_number)
                VALUES (%s, %s, %s, %s, %s, %s)
            ''', (full_name, email, password, role, location, cell_number))
             conn.commit()
             return redirect('/login_manufacturer')
        except Error as e:
            if "Duplicate entry" in str(e):
                message = "Error: Email already exists."
            elif "Can't connect" in str(e):
                message = "Error: Database connection issue."
            else:
                message = f"Error: {str(e)}"
            return render_template('signup_manufacturer.html', message=message)

    return render_template('signup_manufacturer.html',messageM="Successful Register a Manufacere!")

                                                                  
@app.route('/signup_spazaOwner', methods=['GET', 'POST'])
def signup_spazaOwner():
    if request.method == 'POST':
        full_name = request.form.get('full_name')
        email = request.form.get('email')
        password = request.form.get('password')
        location = request.form.get('location', '')  # Optional field
        role = 'spaza_owner'
        cell_number = request.form.get('cell_number')  # Optional field

        # Check phone number validity
       
       #something is wrong

        # Check password strength
        password_strength = check_password_strength(password)
        if password_strength == "Weak":
            return render_template('signup_spazaOwner.html', message="Password is too weak!")
    

        try:
            cursor.execute('''
                INSERT INTO spaza_owner1 (full_name, email, password, role, location, cell_number)
                VALUES (%s, %s, %s, %s, %s, %s)
            ''', (full_name, email, password, role, location, cell_number))
            conn.commit()
            return redirect('/login_spazaOwner',message="Successful Register a Spaza Owner!")
        except Error as e:
            if "Duplicate entry" in str(e):
                message = "Error: Email already exists."
            elif "Can't connect" in str(e):
                message = "Error: Database connection issue."
            else:
                message = f"Error: {str(e)}"
            return render_template('signup_spazaOwner.html', message=message)

    return render_template('signup_spazaOwner.html')

      
@app.route('/manudashboard')
def manudashboard():
    return render_template('manudashboard.html')

@app.route('/shopowner', methods=['GET', 'POST'])
def shopowner():
    return render_template('shopowner.html')

@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')


@app.route('/scan_For_Manufacturer', methods=['GET', 'POST'])
def scan_For_Manufacturer():
    global scanned_data, camera_active, cap
    camera_active = True  # Activate the camera
    scanned_data = None  # Reset scanned data

    if cap is None:
        cap = cv2.VideoCapture(0)
        cap.set(3, 640)  # Set width
        cap.set(4, 480)  # Set height

    while True:
        success, img = cap.read()
        if not success:
            break

        # Decode barcodes in the current frame
        for barcode in decode(img):
            scanned_data = barcode.data.decode('utf-8')  # Store scanned data
            camera_active = False  # Stop camera after scanning

            # Check if the product exists in the database
            try:
                query = "SELECT * FROM Product WHERE prod_barcode = %s"
                cursor.execute(query, (scanned_data,))
                product = cursor.fetchone()

                if product:
                    # If product exists, redirect to update page with product details
                    cap.release()
                    cv2.destroyAllWindows()
                    return render_template('update_product.html', product=product)
                else:
                    # If product does not exist, redirect to input page to add new product
                    cap.release()
                    cv2.destroyAllWindows()
                    return render_template('add_product.html', barcode=scanned_data)

            except Error as e:
                print(f"Database error: {e}")
                cap.release()
                cv2.destroyAllWindows()
                return jsonify({"message": "Database connection error", "error": str(e)})

        # Display the camera feed
        cv2.imshow("Barcode Scanner", img)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()
    return render_template('scan.html', message="No barcode scanned. Please try again.")

# This route queries MySQL based on the scanned barcode
@app.route('/scan_barcode')
def scan_barcode():
    global scanned_data
    barcode = scanned_data

    if not barcode:
        return jsonify({"barcode": "No barcode scanned yet"})

    try:
        connection = mysql.connector.connect(
            host='localhost',
            user='root',
            password='1234567890',
            database='your_database'
        )
        cursor = connection.cursor(dictionary=True)
        query = "SELECT * FROM Product WHERE prod_barcode = %s"
        cursor.execute(query, (barcode,))
        result = cursor.fetchone()
        
        if result:
            # Return all product information as JSON
            return jsonify(result)
        else:
            return jsonify({"barcode": barcode, "message": "No product found for this barcode."})
    
    except Error as e:
        print(f"Database error: {e}")
        return jsonify({"message": "Database connection error", "error": str(e)})
    
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()

@app.route('/add_product', methods=['GET', 'POST'])
def add_product():
    if request.method == 'POST':
        prod_name = request.form['productName']
        prod_barcode = request.form['barcode']
        prod_price = request.form['price']
        prod_quantity = 100  # Default quantity
        prod_description = request.form['description']

        try:
            cursor.execute('''
                INSERT INTO Product (prod_name, prod_barcode, prod_price, prod_quantity, prod_description)
                VALUES (%s, %s, %s, %s, %s)
            ''', (prod_name, prod_barcode, prod_price, prod_quantity, prod_description))
            conn.commit()
            return redirect('/manudashboard')
        except Error as e:
            print(f"Database error: {e}")
            return render_template('add_product.html', message="Error adding product.")

    return render_template('add_product.html')

@app.route('/delete_product', methods=['GET', 'POST'])
def delete_product():
    if request.method == 'POST':
        scan_barcode = request.form['scan_barcode']
        try:
            # Delete product with the same barcode
            cursor.execute("DELETE FROM Product WHERE prod_barcode = %s", (scan_barcode,))
            conn.commit()
            return redirect('/manudashboard')
        except Error as e:
            print(f"Database error: {e}")
            return render_template('delete_product.html', message="Error deleting product.")
        
@app.route('/delete_user', methods=['GET', 'POST'])
def delete_user():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        try:
            # Verify user credentials
            cursor.execute("SELECT id, password FROM spaza_owner1 WHERE email = %s", (email,))
            user = cursor.fetchone()

            if user and user[1] == password:
                user_id = user[0]

                # Check if the user has associated products
                cursor.execute("SELECT COUNT(*) FROM Product WHERE id IN (SELECT id FROM Product WHERE id = %s)", (user_id,))
                product_count = cursor.fetchone()[0]

                if product_count > 0:
                    # Delete all products added by the user
                    cursor.execute("DELETE FROM Product WHERE id IN (SELECT id FROM Product WHERE id = %s)", (user_id,))

                # Delete the user
                cursor.execute("DELETE FROM spaza_owner1 WHERE id = %s", (user_id,))
                conn.commit()

                return render_template('delete_user.html', message="User and associated products deleted successfully!")
            else:
                return render_template('delete_user.html', message="Invalid email or password!")
        except Error as e:
            print(f"Database error: {e}")
            return render_template('delete_user.html', message="Error deleting user.")
    
    return render_template('delete_user.html')



@app.route('/update_product', methods=['GET', 'POST'])
def update_product():
    if request.method == 'POST':
        prod_barcode = request.form['prod_barcode']
        prod_name = request.form['prod_name']
        prod_price = request.form['prod_price']
        prod_quantity = request.form['prod_quantity']
        prod_description = request.form['prod_description']

        try:
            # Update product with the same barcode
            cursor.execute('''
                UPDATE Product
                SET prod_name = %s, prod_price = %s, prod_quantity = %s, prod_description = %s
                WHERE prod_barcode = %s
            ''', (prod_name, prod_price, prod_quantity, prod_description, prod_barcode))
            conn.commit()
            return redirect('/manudashboard')
        except Error as e:
            print(f"Database error: {e}")
            return render_template('update_product.html', message="Error updating product.")
    
    prod_barcode = request.args.get('prod_barcode')
    if prod_barcode:
        try:
            # Fetch product with the same barcode
            cursor.execute("SELECT * FROM Product WHERE prod_barcode = %s", (prod_barcode,))
            product = cursor.fetchone()
            if product:
                return render_template('update_product.html', product=product)
            else:
                return render_template('update_product.html', message="Product not found.")
        except Error as e:
            print(f"Database error: {e}")
            return render_template('update_product.html', message="Error fetching product.")
    
    return render_template('update_product.html', message="No product selected.")

# Flask-Login setup
login_manager = LoginManager()
login_manager.init_app(app)

class User(UserMixin):
    def __init__(self, id, email):
        self.id = id
        self.email = email

@login_manager.user_loader
def load_user(user_id):
    return User(user_id, "demo@example.com")

@app.route('/login')
def login():
    user = User("1", "demo@example.com")
    login_user(user)
    return redirect(url_for('scan_page'))



@app.route('/start_camera')
def start_camera():
    global camera_active, scanned_data
    camera_active = True
    scanned_data = None
    return jsonify({"status": "Camera started"})

@app.route('/process_scanned_barcode', methods=['POST'])
@login_required
def process_scanned_barcode():
    barcode = request.form.get('barcode')
    try:
        cursor.execute("SELECT * FROM Product WHERE prod_barcode = %s", (barcode,))
        product = cursor.fetchone()
    except Error as e:
        print(f"Database error: {e}")
        product = None

    if product:
        return render_template("confirm_update.html", product=product)
    else:
        return redirect(url_for('add_product', barcode=barcode))

@app.route('/update_product_by_id/<int:product_id>', methods=['GET', 'POST'])
@login_required
def update_product_by_id(product_id):
    cursor.execute("SELECT * FROM Product")
    products = cursor.fetchall()
    for p in products:
        if p['id'] == product_id:
            if request.method == 'POST':
                # Update logic here
                p['prod_name'] = request.form['prod_name']
                # p['expiration_date'] = request.form['expiration_date']  # Add if stored
                return redirect(url_for('scan_page'))
            return render_template("update_product.html", product=p)
    return "Product not found", 404


if __name__ == "__main__":
    app.run(debug=True)
