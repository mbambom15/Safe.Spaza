
from flask import Flask, render_template, Response, request, redirect, url_for, jsonify, session
from datetime import datetime, date
from flask import url_for
import cv2
import numpy as np
from pyzbar.pyzbar import decode
import mysql.connector
from mysql.connector import Error
from io import StringIO, BytesIO
import csv
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors
from flask_session import Session
import os
import os
from flask import url_for, current_app

app = Flask(__name__, template_folder='temp', static_folder='static')
app.secret_key = os.environ.get('FLASK_SECRET_KEY', 'fallback-secret-key-change-me')
app.config['SESSION_TYPE'] = 'filesystem'
Session(app)

def create_connection():
    return mysql.connector.connect(
        host="localhost",      
        user="mbambo",    
        password="Mbambo1307#a",
        database="spaza_safe"      
    )

# Global variables for barcode scanning
scanned_data = None
camera_active = False
cap = None

def generate_frames():
    global scanned_data, camera_active, cap
    
    if cap is None or not cap.isOpened():
        cap = cv2.VideoCapture(0)
        cap.set(3, 640)
        cap.set(4, 480)

    try:
        while True:
            if camera_active:
                success, img = cap.read()
                if not success:
                    break
                
                # Only process frame if we don't already have scanned data
                if scanned_data is None:
                    barcodes = decode(img)
                    if barcodes:
                        for barcode in barcodes:
                            scanned_data = barcode.data.decode('utf-8')
                            # Draw bounding box
                           # pts = np.array([barcode.polygon], np.int32)
                           # pts = pts.reshape((-1, 1, 2))
                            #cv2.polylines(img, [pts], True, (255, 0, 255), 5)
                            # Display text
                            x, y, _, _ = barcode.rect
                            cv2.putText(img, scanned_data, (x, y - 10), 
                                       cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 0, 255), 2)
                
                _, buffer = cv2.imencode('.jpg', img)
                frame = buffer.tobytes()
                yield (b'--frame\r\n'
                       b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
            else:
                # Paused frame
                blank_frame = np.zeros((480, 640, 3), dtype=np.uint8)
                cv2.putText(blank_frame, "Camera Paused", (220, 240), 
                           cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
                _, buffer = cv2.imencode('.jpg', blank_frame)
                frame = buffer.tobytes()
                yield (b'--frame\r\n'
                       b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
    except Exception as e:
        print(f"Camera error: {e}")
    finally:
        if cap is not None:
            cap.release()
            cap = None
@app.route('/clear_scanned_data')
def clear_scanned_data():
    global scanned_data, camera_active
    scanned_data = None
    camera_active = True  # Ensure camera stays active
    return jsonify({"status": "Scanned data cleared", "camera_active": camera_active})

#handle all new customer routes such as login and signup, plus linking pages here
@app.route('/login_customer', methods=['GET', 'POST'])
def login_customer():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        if not all([email, password]):
            return jsonify({"success": False, "message": "All fields are required"}), 400

        connection = None
        try:
            connection = create_connection()
            cursor = connection.cursor(dictionary=True)
            
            # Check if customer exists
            cursor.execute("""
                SELECT * FROM Customer 
                WHERE email = %s AND cpassword = %s
            """, (email, password))
            
            customer = cursor.fetchone()
            
            if customer:
                return jsonify({
                    "success": True,
                    "message": "Login successful",
                    "redirect": url_for('dashboard'),  # Change to your customer dashboard route
                    "user": {
                        "id": customer['cust_id'],
                        "email": customer['email']
                    }
                })
            else:
                return jsonify({
                    "success": False,
                    "message": "Invalid email or password"
                }), 401

        except Error as e:
            return jsonify({
                "success": False,
                "message": f"Database error: {str(e)}"
            }), 500

        finally:
            if connection and connection.is_connected():
                cursor.close()
                connection.close()

    return render_template('login_customer.html')
@app.route('/signup_customer', methods=['GET', 'POST'])
def signup_customer():
    if request.method == 'POST':
        email = request.form.get('email')
        phone = request.form.get('phone')
        password = request.form.get('password')
        confirm = request.form.get('confirm')

        # Validation
        if not all([email, phone, password, confirm]):
            return jsonify({"success": False, "message": "All fields are required"}), 400

        if password != confirm:
            return jsonify({"success": False, "message": "Passwords do not match"}), 400

        if len(phone) != 10 or not phone.isdigit():
            return jsonify({"success": False, "message": "Phone number must be 10 digits"}), 400

        connection = None
        try:
            connection = create_connection()
            cursor = connection.cursor(dictionary=True)

            # Check if email already exists
            cursor.execute("SELECT email FROM Customer WHERE email = %s", (email,))
            if cursor.fetchone():
                return jsonify({"success": False, "message": "Email already registered"}), 400

            # Insert new customer
            query = """
                INSERT INTO Customer (email, telephone, cpassword)
                VALUES (%s, %s, %s)
            """
            cursor.execute(query, (email, phone, password))
            connection.commit()

            return jsonify({
                "success": True,
                "message": "Account created successfully!",
                "redirect": url_for('login_customer')
            })

        except Error as e:
            if connection:
                connection.rollback()
            return jsonify({
                "success": False,
                "message": f"Registration failed: {str(e)}"
            }), 500

        finally:
            if connection and connection.is_connected():
                cursor.close()
                connection.close()

    return render_template('signup_customer.html')
            
@app.route('/update_password_owner', methods=['GET', 'POST'])
def update_password_owner():
    if request.method == 'POST':
        data = request.form
        username = data.get('owner_name')
        new_password = data.get('new_password')

        if not all([username, new_password]):
            return redirect(url_for('login_spazaOwner', message="Username and new password are required"))

        if len(new_password) > 15:
            return redirect(url_for('login_spazaOwner', message="Password must be 15 characters or less"))

        connection = None
        try:
            connection = create_connection()
            cursor = connection.cursor()

            query = "UPDATE Spaza_Owner SET opassword = %s WHERE oname = %s"
            cursor.execute(query, (new_password, username))
            connection.commit()

            if cursor.rowcount == 0:
                return redirect(url_for('login_spazaOwner', message="Shop owner not found"))

            return redirect(url_for('login_spazaOwner', message="Password updated successfully"))

        except Error as e:
            if connection:
                connection.rollback()
            return redirect(url_for('login_spazaOwner', message=f"Error: {str(e)}"))

        finally:
            if connection and connection.is_connected():
                cursor.close()
                connection.close()

    return render_template('update_passwordo.html')


@app.route('/update_password_manufacturer', methods=['GET', 'POST'])
def update_password_manufacturer():
            if request.method == 'POST':
                data = request.form
                license_key = data.get('license_key')
                new_password = data.get('new_password')

                if not all([license_key, new_password]):
                    return redirect(url_for('login_manufacturer', message="License key and new password are required"))

                if len(new_password) > 15:
                    return redirect(url_for('login_manufacturer', message="Password must be 15 characters or less"))

                connection = None
                try:
                    connection = create_connection()
                    cursor = connection.cursor()

                    query = "UPDATE Manufacturer SET mpassword = %s WHERE license_key = %s"
                    cursor.execute(query, (new_password, license_key))
                    connection.commit()

                    if cursor.rowcount == 0:
                        return redirect(url_for('login_manufacturer', message="Manufacturer not found"))

                    return redirect(url_for('login_manufacturer', message="Password updated successfully"))

                except Error as e:
                    if connection:
                        connection.rollback()
                    return redirect(url_for('login_manufacturer', message=f"Error: {str(e)}"))

                finally:
                    if connection and connection.is_connected():
                        cursor.close()
                        connection.close()

            return render_template('update_password.html')

@app.route('/')
def home():
    
    return render_template('home.html')

@app.route('/spazalogin')
def spazalogin():
    return render_template('spazalogin.html')

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

@app.route('/scan')
def scan():
    return render_template('scan.html')

@app.route('/login_spazaOwner', methods=['GET', 'POST'])
def login_spazaOwner():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        if not all([username, password]):
            return jsonify({"success": False, "message": "All fields are required"}), 400

        connection = None
        try:
            connection = create_connection()
            cursor = connection.cursor(dictionary=True)
            
            cursor.execute("""
                SELECT o.*, s.business_reg_number 
                FROM Spaza_Owner o
                JOIN Spaza_Shop s ON o.business_reg_number = s.business_reg_number
                WHERE (o.oname = %s OR o.business_name = %s) AND o.opassword = %s
            """, (username, username, password))
            
            shop_owner = cursor.fetchone()
            
            if shop_owner:
                # Update last_login timestamp
                cursor.execute("""
                    UPDATE Spaza_Owner 
                    SET last_login = CURRENT_TIMESTAMP
                    WHERE owner_id = %s
                """, (shop_owner['owner_id'],))
                connection.commit()
                
                # Set session variables
                session['owner_id'] = shop_owner['owner_id']
                session['business_reg_number'] = shop_owner['business_reg_number']
                session['business_name'] = shop_owner['business_name']
                
                return jsonify({
                    "success": True,
                    "message": "Login successful",
                    "redirect": url_for('shopowner'),
                    "user": {
                        "id": shop_owner['owner_id'],
                        "name": shop_owner['business_name'],
                        "business_reg_number": shop_owner['business_reg_number']
                    }
                })
            else:
                return jsonify({
                    "success": False,
                    "message": "Invalid credentials"
                }), 401

        except Error as e:
            return jsonify({
                "success": False,
                "message": f"Database error: {str(e)}"
            }), 500
        finally:
            if connection and connection.is_connected():
                cursor.close()
                connection.close()

    return render_template('login_spazaOwner.html')
            
@app.route('/login_manufacturer', methods=['GET', 'POST'])
def login_manufacturer():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        if not all([username, password]):
            return jsonify({"success": False, "message": "All fields are required"}), 400

        connection = None
        try:
            connection = create_connection()
            cursor = connection.cursor(dictionary=True)

            cursor.execute("""
                SELECT license_key, company_name FROM Manufacturer
                WHERE license_key = %s AND mpassword = %s
            """, (username, password))

            manufacturer = cursor.fetchone()

            if manufacturer:
                # Update last_login timestamp upon successful login
                cursor.execute("""
                    UPDATE Manufacturer 
                    SET last_login = CURRENT_TIMESTAMP 
                    WHERE license_key = %s
                """, (username,))
                connection.commit()

                return jsonify({
                    "success": True,
                    "message": "Login successful",
                    "redirect": url_for('manudashboard'),
                    "user": {
                        "id": manufacturer['license_key'],
                        "name": manufacturer['company_name']
                    }
                })
            else:
                return jsonify({
                    "success": False,
                    "message": "Invalid credentials"
                }), 401

        except Error as e:
            return jsonify({
                "success": False,
                "message": f"Database error: {str(e)}"
            }), 500
        finally:
            if connection and connection.is_connected():
                cursor.close()
                connection.close()

    return render_template('login_manufacturer.html')

@app.route('/signup_manufacturer', methods=['GET', 'POST'])
def signup_manufacturer():
    if request.method == 'POST':
        license_key = request.form.get('license_key')
        company_name = request.form.get('company_name')
        address = request.form.get('address')
        location = request.form.get('location')
        password = request.form.get('password')

        if not all([license_key, company_name, address, location, password]):
            return jsonify({
                "success": False,
                "message": "All fields are required"
            }), 400

        connection = None
        try:
            connection = create_connection()
            cursor = connection.cursor()

            cursor.execute("SELECT license_key FROM Manufacturer WHERE license_key = %s", (license_key,))
            if cursor.fetchone():
                return jsonify({
                    "success": False,
                    "message": "License key already registered"
                }), 400

            # creationdate will be automatically set by DEFAULT CURRENT_TIMESTAMP
            query = """
                INSERT INTO Manufacturer (license_key, company_name, address, location, mpassword)
                VALUES (%s, %s, %s, %s, %s)
            """
            cursor.execute(query, (license_key, company_name, address, location, password))
            connection.commit()

            return jsonify({
                "success": True,
                "message": "Registration successful",
                "redirect": url_for('login_manufacturer')
            })

        except Error as e:
            if connection:
                connection.rollback()
            return jsonify({
                "success": False,
                "message": f"Database error: {str(e)}"
            }), 500
        finally:
            if connection and connection.is_connected():
                cursor.close()
                connection.close()

    return render_template('signup_manufacturer.html')

@app.route('/signup_spazaOwner', methods=['GET', 'POST'])
def signup_spazaOwner():
    if request.method == 'POST':
        form_data = {
            'oname': request.form.get('oname'),
            'opassword': request.form.get('opassword'),
            'phone_number': request.form.get('phone_number'),
            'business_name': request.form.get('business_name'),
            'business_reg_number': request.form.get('business_reg_number'),
            'location': request.form.get('location')
        }

        # Validate all required fields
        missing_fields = [field for field, value in form_data.items() if not value and field != 'phone_number']
        if missing_fields:
            return jsonify({
                "success": False,
                "message": f"Missing required fields: {', '.join(missing_fields)}"
            }), 400

        # Validate password length
        if len(form_data['opassword']) > 15:
            return jsonify({
                "success": False,
                "message": "Password must be 15 characters or less"
            }), 400

        connection = None
        try:
            connection = create_connection()
            cursor = connection.cursor()

            # Check if business registration number already exists
            cursor.execute("""
                SELECT business_reg_number 
                FROM Spaza_Owner 
                WHERE business_reg_number = %s
            """, (form_data['business_reg_number'],))
            
            if cursor.fetchone():
                return jsonify({
                    "success": False,
                    "message": "Business registration number already exists"
                }), 400

            # Insert new shop owner
            cursor.execute("""
                INSERT INTO Spaza_Owner 
                (oname, opassword, phone_number, business_name, business_reg_number)
                VALUES (%s, %s, %s, %s, %s)
            """, (
                form_data['oname'],
                form_data['opassword'],
                form_data['phone_number'],
                form_data['business_name'],
                form_data['business_reg_number']
            ))
            
            # Get the newly created owner_id
            owner_id = cursor.lastrowid
            
            # Insert corresponding shop using the same business_reg_number
            cursor.execute("""
                INSERT INTO Spaza_Shop 
                (business_reg_number, sname, owner_id, location)
                VALUES (%s, %s, %s, %s)
            """, (
                form_data['business_reg_number'],
                form_data['business_name'],
                owner_id,
                form_data['location']
            ))
            
            connection.commit()

            return jsonify({
                "success": True,
                "message": "Registration successful! Redirecting to login...",
                "redirect": url_for('login_spazaOwner'),
                "business_reg_number": form_data['business_reg_number']
            })

        except Exception as e:
            if connection:
                connection.rollback()
            return jsonify({
                "success": False,
                "message": f"Registration failed: {str(e)}"
            }), 500

        finally:
            if connection and connection.is_connected():
                cursor.close()
                connection.close()

    return render_template('signup_spazaOwner.html')

@app.route('/manudashboard')
def manudashboard():
    return render_template('manudashboard.html')
# Product dictionary in Flask app

# Update the product database with more products
PRODUCT_DATABASE = {
    '6009644140053': {
        'prod_name': 'Olive Oil',
        'prod_price': 64.00,
        'prod_expiry_date': '2027-03-12',
        'prod_manu_date': '2025-03-14',
        'prod_quantity': 50,
    },
    '6001038284909': {
        'prod_name': 'Garlic Salt',
        'prod_price': 35.00,
        'prod_expiry_date': '2025-06-15',
        'prod_manu_date': '2023-04-25',
        'prod_quantity': 100
    },
    '6002310013569': {
        'prod_name': 'Pride Popcorn',
        'prod_price': 25.00,
        'prod_expiry_date': '2025-07-15',
        'prod_manu_date': '2023-04-25',
        'prod_quantity': 100
    }
    
    
}
#duplicate get product for spazashop view
@app.route('/get_product_dataspz/<barcode>')
def get_product_dataspz(barcode):
    connection = None
    try:
        connection = create_connection()
        cursor = connection.cursor(dictionary=True)
        query = "SELECT * FROM Product WHERE prod_barcode = %s"
        cursor.execute(query, (barcode,))
        product = cursor.fetchone()
        if product:
            return jsonify({"success": True, "product": product})
        else:
            return jsonify({"success": False, "message": "Product not found"})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)})
    finally:
        if connection and connection.is_connected():
            cursor.close()
            connection.close()

@app.route('/get_product_data/<barcode>')
def get_product_data(barcode):
    product = PRODUCT_DATABASE.get(barcode)
    if product:
        # Generate image URL and check existence
        image_filename = f"{barcode}.png"
        static_folder = current_app.static_folder
        image_path = os.path.join(static_folder, 'images', 'products', image_filename)
        image_exists = os.path.exists(image_path)
        
        # Generate URL (Flask will handle the static path)
        image_url = url_for('static', filename=f'images/products/{image_filename}')
        
        return jsonify({
            "success": True,
            "product": {
                "prod_name": product['prod_name'],
                "prod_price": product['prod_price'],
                "prod_expiry_date": product['prod_expiry_date'],
                "prod_manu_date": product['prod_manu_date'],
                "prod_quantity": product['prod_quantity'],
                "prod_image_url": image_url,
                "image_exists": image_exists
            }
        })
    return jsonify({"success": False, "message": "Product not found"})

@app.route('/stop_camera')
def stop_camera():
    global camera_active, cap
    camera_active = False
    if cap is not None:
        cap.release()
        cap = None
    return jsonify({"status": "Camera stopped"})

#Add product for manufacturrer
@app.route('/add_product', methods=['POST'])
def add_product():
    data = request.json
    connection = None

    try:
        product_info = PRODUCT_DATABASE.get(data['barcode'])
        if not product_info:
            return jsonify({"success": False, "message": "Product not found in database"}), 404

        expiry_date = datetime.strptime(product_info['prod_expiry_date'], '%Y-%m-%d').date()
        today = datetime.now().date()

        if expiry_date < today:
            return jsonify({
                "success": False,
                "message": f"Cannot add product - it expired on {product_info['prod_expiry_date']}"
            }), 400

        # Generate relative image URL (works for both local and production)
        image_filename = f"{data['barcode']}.png"
        image_url = url_for('static', filename=f'images/products/{image_filename}')  # Removed _external=True
        
        # Check if image exists in static folder
        static_folder = current_app.static_folder
        image_path = os.path.join(static_folder, 'images', 'products', image_filename)
        
        # Only store URL if image exists
        if not os.path.exists(image_path):
            image_url = ""

        connection = create_connection()
        cursor = connection.cursor()

        # Check for existing product
        cursor.execute("""
            SELECT prod_barcode FROM Product 
            WHERE prod_barcode = %s AND license_key = %s
        """, (data['barcode'], data['license_key']))

        if cursor.fetchone():
            return jsonify({"success": False, "message": "You have already added this product"})

        # Insert product with image URL
        query = """
        INSERT INTO Product (prod_barcode, prod_name, prod_price, 
                           prod_expiry_date, prod_manu_date, 
                           license_key, prod_quantity, time_created, prod_image_url)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        cursor.execute(query, (
            data['barcode'],
            product_info['prod_name'],
            product_info['prod_price'],
            product_info['prod_expiry_date'],
            product_info['prod_manu_date'],
            data['license_key'],
            product_info['prod_quantity'],
            datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            image_url  # Now stores relative URL or empty string
        ))

        connection.commit()
        return jsonify({
            "success": True,
            "message": "Product added successfully",
            "product": {
                "prod_barcode": data['barcode'],
                "prod_name": product_info['prod_name'],
                "prod_price": product_info['prod_price'],
                "prod_expiry_date": product_info['prod_expiry_date'],
                "prod_quantity": product_info['prod_quantity'],
                "prod_image_url": image_url  # Returns the relative URL
            }
        })
    except Error as e:
        if connection:
            connection.rollback()
        return jsonify({"success": False, "message": str(e)}), 500
    finally:
        if connection and connection.is_connected():
            cursor.close()
            connection.close()


#Add the update route for the manufacturer prices here
@app.route('/update_product', methods=['PUT'])
def update_product():
    data = request.json
    connection = None
    
    if not data or 'barcode' not in data or 'price' not in data or 'license_key' not in data:  # Changed here
        return jsonify({"success": False, "message": "Invalid request data"}), 400

    try:
        connection = create_connection()
        cursor = connection.cursor()

        query = """
        UPDATE Product
        SET prod_price = %s
        WHERE prod_barcode = %s AND license_key = %s  # Changed here
        """
        cursor.execute(query, (
            data['price'],
            data['barcode'],
            data['license_key']  # Changed here
        ))

        if cursor.rowcount == 0:
            return jsonify({"success": False, "message": "Product not found or not owned by manufacturer"}), 404

        connection.commit()
        return jsonify({"success": True, "message": "Product updated successfully"})

    except Error as e:
        if connection:
            connection.rollback()
        return jsonify({"success": False, "message": str(e)}), 500
    finally:
        if connection and connection.is_connected():
            cursor.close()
            connection.close()
# ADD the delete route for the manufacturer here
@app.route('/delete_product/<barcode>', methods=['DELETE'])
def delete_product(barcode):
    license_key = request.args.get('license_key')  # Changed here
    
    if not license_key:
        return jsonify({"success": False, "message": "License key is required"}), 400  # Changed here

    try:
        connection = create_connection()
        cursor = connection.cursor()

        query = "DELETE FROM Product WHERE prod_barcode = %s AND license_key = %s"  # Changed here
        cursor.execute(query, (barcode, license_key))  # Changed here

        if cursor.rowcount == 0:
            return jsonify({"success": False, "message": "Product not found or not owned by manufacturer"}), 404

        connection.commit()
        return jsonify({"success": True, "message": "Product deleted successfully"})

    except Error as e:
        if connection:
            connection.rollback()
        return jsonify({"success": False, "message": str(e)}), 500
    finally:
        if connection and connection.is_connected():
            cursor.close()
            connection.close()

@app.route('/get_products')
def get_products():
    license_key = request.args.get('license_key')  # Changed from manufacturer_id
    
    if not license_key:
        return jsonify({"success": False, "message": "License key is required"}), 400

    connection = None
    try:
        connection = create_connection()
        cursor = connection.cursor(dictionary=True)
        
        # Verify the manufacturer exists 
        cursor.execute("SELECT license_key FROM Manufacturer WHERE license_key = %s", (license_key,))
        if not cursor.fetchone():
            return jsonify({"success": False, "message": "Invalid license key"}), 401
        
        # Get only products belonging to this manufacturer
        query = "SELECT * FROM Product WHERE license_key = %s"
        cursor.execute(query, (license_key,))
        products = cursor.fetchall()
        
        return jsonify(products)
        
    except Error as e:
        return jsonify({"success": False, "message": str(e)}), 500
    finally:
        if connection and connection.is_connected():
            cursor.close()
            connection.close()
#this is also a manufacturer getting products
@app.route('/get_product')
def get_product():
    barcode = request.args.get('barcode')
    license_key = request.args.get('license_key')  # Changed here
    
    if not all([barcode, license_key]):
        return jsonify({"success": False, "message": "Barcode and license key are required"}), 400  # Changed here
    
    connection = None
    try:
        connection = create_connection()
        cursor = connection.cursor(dictionary=True)
        
        query = "SELECT * FROM Product WHERE prod_barcode = %s AND license_key = %s"  # Changed here
        cursor.execute(query, (barcode, license_key))  # Changed here
        product = cursor.fetchone()
        
        if not product:
            return jsonify({"success": False, "message": "Product not found"}), 404
        
        return jsonify(product)
        
    except Error as e:
        return jsonify({"success": False, "message": str(e)}), 500
    finally:
        if connection and connection.is_connected():
            cursor.close()
            connection.close()

@app.route('/order_stock')
def order_stock():
    return render_template('order_stock.html')


@app.route('/shopowner.html')
def shopowner():
    return render_template('shopowner.html')




@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

# This route queries MySQL based on the scanned barcode
@app.route('/scan_barcode')
def scan_barcode():
    global scanned_data
    barcode = scanned_data

    if not barcode:
        return jsonify({"barcode": "No barcode scanned yet"})

    try:
        connection = create_connection()
        cursor = connection.cursor(dictionary=True)
        query = "SELECT * FROM Product WHERE prod_barcode = %s"
        cursor.execute(query, (barcode,))
        result = cursor.fetchone()
        
        if result:
            # Return all product information as JSON
            return jsonify(result)
        else:
            return jsonify({"barcode": barcode, "message": "No product found for this barcode."})
    
    except Error as e:
        print(f"Database error: {e}")
        return jsonify({"message": "Database connection error", "error": str(e)})
    
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()

@app.route('/check_expiring_products')
def check_expiring_products():
    registration_no = request.args.get('registration_no')
    days_threshold = request.args.get('days', default=7, type=int)
    
    if not registration_no:
        return jsonify({"success": False, "message": "Registration number is required"}), 400
    
    connection = None
    try:
        connection = create_connection()
        cursor = connection.cursor(dictionary=True)
        
        # Get expired products (already past expiry date)
        cursor.execute("""
            SELECT p.prod_barcode, p.prod_name, p.prod_expiry_date, si.shop_price
            FROM Shop_Inventory si
            JOIN Product p ON si.prod_barcode = p.prod_barcode
            WHERE si.registration_no = %s 
            AND p.prod_expiry_date < CURDATE()
        """, (registration_no,))
        expired = cursor.fetchall()
        
        # Get products expiring soon (within next 7 days)
        cursor.execute("""
            SELECT p.prod_barcode, p.prod_name, p.prod_expiry_date, si.shop_price
            FROM Shop_Inventory si
            JOIN Product p ON si.prod_barcode = p.prod_barcode
            WHERE si.registration_no = %s 
            AND p.prod_expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL %s DAY)
        """, (registration_no, days_threshold))
        expiring_soon = cursor.fetchall()
        
        return jsonify({
            "success": True,
            "expired_products": expired,
            "expiring_products": expiring_soon
        })
        
    except Error as e:
        return jsonify({"success": False, "message": str(e)}), 500
    finally:
        if connection and connection.is_connected():
            cursor.close()
            connection.close()

@app.route('/check_manufacturer_expiry')
def check_manufacturer_expiry():
    manufacturer_id = request.args.get('manufacturer_id')
    days_threshold = request.args.get('days', default=7, type=int)
    
    if not manufacturer_id:
        return jsonify({"success": False, "message": "Manufacturer ID is required"}), 400
    
    connection = None
    try:
        connection = create_connection()
        cursor = connection.cursor(dictionary=True)
        
        # Get expired products (already past expiry date)
        cursor.execute("""
            SELECT prod_barcode, prod_name, prod_expiry_date
            FROM Product
            WHERE license_key = %s 
            AND prod_expiry_date < CURDATE()
        """, (manufacturer_id,))
        expired = cursor.fetchall()
        
        # Get products expiring soon (within next 7 days)
        cursor.execute("""
            SELECT prod_barcode, prod_name, prod_expiry_date
            FROM Product
            WHERE license_key = %s 
            AND prod_expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL %s DAY)
        """, (manufacturer_id, days_threshold))
        expiring_soon = cursor.fetchall()
        
        return jsonify({
            "success": True,
            "expired_products": expired,
            "expiring_products": expiring_soon
        })
        
    except Error as e:
        return jsonify({"success": False, "message": str(e)}), 500
    finally:
        if connection and connection.is_connected():
            cursor.close()
            connection.close()

#Report generating for manufacturer
@app.route('/report_page')
def report_page():
    license_key = request.args.get('license_key')
    if not license_key:
        return "License key required", 400
    return render_template('report.html', license_key=license_key)

#Get the manufacturers report
@app.route('/manufacturer_report')
def manufacturer_report():
    license_key = request.args.get('license_key')
    if not license_key:
        return jsonify({"success": False, "error": "License key is required"}), 400

    try:
        connection = create_connection()
        if not connection:
            return jsonify({"success": False, "error": "Database connection failed"}), 500
            
        cursor = connection.cursor(dictionary=True)
        
        # Query using the ManufacturerProductsReport view
        query = """
            SELECT * FROM ManufacturerProductsReport 
            WHERE license_key = %s
            ORDER BY expiry_date
        """
        
        cursor.execute(query, (license_key,))
        products = cursor.fetchall()
        
        if not products:
            return jsonify({
                "success": True,
                "data": [],
                "message": "No products found for this manufacturer"
            })
        
        # Convert datetime objects to strings
        for product in products:
            for field in ['manufacture_date', 'expiry_date', 'added_date', 
                         'manufacturer_last_login', 'manufacturer_created']:
                if product.get(field) and isinstance(product[field], (datetime, date)):
                    product[field] = product[field].isoformat()
        
        return jsonify({
            "success": True,
            "data": products
        })
        
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e),
            "message": "Failed to fetch manufacturer report"
        }), 500
    finally:
        if connection and connection.is_connected():
            cursor.close()
            connection.close()
            
#Spaza Shop new routes from new design 
@app.route('/get_shop_inventory')
def get_shop_inventory():
    registration_no = session.get('registration_no')
    if not registration_no:
        return jsonify({'success': False, 'message': 'Not logged in'}), 401

    connection = None
    try:
        connection = create_connection()
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM Shop_Inventory WHERE registration_no = %s", (registration_no,))
        inventory = cursor.fetchall()
        return jsonify({'success': True, 'inventory': inventory})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500
    finally:
        if connection and connection.is_connected():
            cursor.close()
            connection.close()

@app.route('/add_to_shop_inventory', methods=['POST'])
def add_to_shop_inventory():
    data = request.json
    business_reg_number = session.get('business_reg_number')  # Changed to match your schema
    prod_barcode = data.get('prod_barcode')
    shop_price = data.get('shop_price')
    stock_quantity = data.get('stock_quantity')

    if not all([business_reg_number, prod_barcode, shop_price, stock_quantity]):
        return jsonify({
            "success": False, 
            "message": f"Missing required fields. Received: {data}",
            "missing": [k for k, v in {
                'business_reg_number': business_reg_number,
                'prod_barcode': prod_barcode,
                'shop_price': shop_price,
                'stock_quantity': stock_quantity
            }.items() if not v]
        }), 400

    connection = None
    try:
        connection = create_connection()
        cursor = connection.cursor()

        # Check if product exists in Product table first
        cursor.execute("SELECT 1 FROM Product WHERE prod_barcode = %s", (prod_barcode,))
        if not cursor.fetchone():
            return jsonify({
                "success": False,
                "message": "Product does not exist in system"
            }), 404

        # Check if this product already exists in this shop's inventory
        cursor.execute("""
            SELECT inventory_id FROM Shop_Inventory 
            WHERE business_reg_number = %s AND prod_barcode = %s
        """, (business_reg_number, prod_barcode))
        result = cursor.fetchone()

        if result:
            # Update existing inventory
            update_query = """
                UPDATE Shop_Inventory 
                SET shop_price = %s, stock_quantity = stock_quantity + %s
                WHERE business_reg_number = %s AND prod_barcode = %s
            """
            cursor.execute(update_query, (
                shop_price,
                stock_quantity,
                business_reg_number,
                prod_barcode
            ))
            message = "Inventory updated"
        else:
            # Insert new inventory record
            insert_query = """
                INSERT INTO Shop_Inventory 
                (business_reg_number, prod_barcode, shop_price, stock_quantity)
                VALUES (%s, %s, %s, %s)
            """
            cursor.execute(insert_query, (
                business_reg_number,
                prod_barcode,
                shop_price,
                stock_quantity
            ))
            message = "Product added to inventory"

        connection.commit()
        return jsonify({"success": True, "message": message})

    except Exception as e:
        print("Error in add_to_shop_inventory:", str(e))
        if connection:
            connection.rollback()
        return jsonify({
            "success": False,
            "message": str(e),
            "error_type": type(e).__name__
        }), 500
    finally:
        if connection and connection.is_connected():
            cursor.close()
            connection.close()
            
@app.route('/get_all_products')
def get_all_products():
    connection = None
    try:
        connection = create_connection()
        cursor = connection.cursor(dictionary=True)
        query = "SELECT * FROM Product"
        cursor.execute(query)
        products = cursor.fetchall()
        return jsonify({"success": True, "products": products})
    except Error as e:
        return jsonify({"success": False, "message": str(e)}), 500
    finally:
        if connection and connection.is_connected():
            cursor.close()
            connection.close()
@app.route('/get_manufacturer/<license_key>')
def get_manufacturer(license_key):
    connection = None
    try:
        connection = create_connection()
        cursor = connection.cursor(dictionary=True)
        query = "SELECT * FROM Manufacturer WHERE license_key = %s"
        cursor.execute(query, (license_key,))
        manufacturer = cursor.fetchone()
        if manufacturer:
            return jsonify({"success": True, "manufacturer": manufacturer})
        else:
            return jsonify({"success": False, "message": "Manufacturer not found"})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)})
    finally:
        if connection and connection.is_connected():
            cursor.close()
            connection.close()
@app.route('/searchAvailableProducts')
def search_available_products():
    query = request.args.get('q', '').strip()
    registration_no = session.get('registration_no')
    if not registration_no:
        return jsonify({"success": False, "message": "Not logged in"}), 401

    connection = None
    try:
        connection = create_connection()
        cursor = connection.cursor(dictionary=True)
        if not query:
            cursor.execute("SELECT * FROM Shop_Inventory WHERE registration_no = %s", (registration_no,))
            products = cursor.fetchall()
            return jsonify({"success": True, "products": products})
        sql = """
            SELECT * FROM Shop_Inventory
            WHERE registration_no = %s AND (
                prod_name LIKE %s
                OR CAST(shop_price AS CHAR) LIKE %s
                OR CAST(last_updated AS CHAR) LIKE %s
            )
        """
        like_query = f"%{query}%"
        cursor.execute(sql, (registration_no, like_query, like_query, like_query))
        products = cursor.fetchall()
        return jsonify({"success": True, "products": products})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)})
    finally:
        if connection and connection.is_connected():
            cursor.close()
            connection.close()
@app.route('/search_products')
def search_products():
    query = request.args.get('q', '').strip()
    connection = None
    try:
        connection = create_connection()
        cursor = connection.cursor(dictionary=True)
        if not query:
            cursor.execute("SELECT * FROM Product")
            products = cursor.fetchall()
            return jsonify({"success": True, "products": products})
        sql = """
            SELECT * FROM Product
            WHERE prod_name LIKE %s
               OR CAST(prod_price AS CHAR) LIKE %s
               OR CAST(prod_expiry_date AS CHAR) LIKE %s
        """
        like_query = f"%{query}%"
        cursor.execute(sql, (like_query, like_query, like_query))
        products = cursor.fetchall()
        return jsonify({"success": True, "products": products})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)})
    finally:
        if connection and connection.is_connected():
            cursor.close()
if __name__ == "__main__":
    app.run(debug=True)
